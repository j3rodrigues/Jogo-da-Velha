public class Tui {
	
	Tabuleiro tab;
	
	public Tui(Tabuleiro tab) {
		this.tab = tab;
	}
		
	private char [][] matriz = new char [][] {
		{'*', '|', '*', '|', '*'}, //0.0 0.1 0.2 0.3 0.4
		{'*', '|', '*', '|', '*'}, //1.0 1.1 1.2 1.3 1.4
		{'*', '|', '*', '|', '*'}  //2.0 2.1 2.2 2.3 2.4
	};
	
	private void linhasEcolunas() {
		for(int l=0; l<3; l++) {
			for(int c=0; c<3; c++) {
				matriz[l][c*2] = tab.getMatriz(l,c);
			}
		}
		
	}
	
	public void exibirTui( ) {
		linhasEcolunas();
		for(int i = 0; i < 3; i++) {
			for(int j = 0; j < 5; j++) {
				System.out.print(matriz[i][j]);
			}
			System.out.println(" ");
		}
	}
	
//	private char verificarVencedor() {
//		for (int i = 0; i < 3; i++) {
//			//linhasO
//				if (matriz[i][0] == tab.jAux.getMarcador() && matriz[i][1] == tab.jAux.getMarcador() && matriz[i][2] == tab.jAux.getMarcador()) {
//					return tab.jAux.getMarcador();
//				}
//		}
//		for (int i = 0; i < 5; i++) {
//			//colunas
//			if (matriz[0][i] == tab.jAux.getMarcador() && matriz[1][i] == tab.jAux.getMarcador() && matriz[2][i] == tab.jAux.getMarcador()) {
//				return tab.jAux.getMarcador();
//			}
//		}
//			//diagonais
//			if (matriz[0][0] == tab.jAux.getMarcador() && matriz[1][1] == tab.jAux.getMarcador() && matriz[2][2] == tab.jAux.getMarcador()) {
//				return tab.jAux.getMarcador();
//			}
//			if (matriz[0][2] == tab.jAux.getMarcador() && matriz[1][1] == tab.jAux.getMarcador() && matriz[2][0] == tab.jAux.getMarcador()) {
//				return tab.jAux.getMarcador();
//			}
//		return 'N';
//	}
//	public char verificar() {
//		//o j1 (X) vencedor
//		if(tab.jAux.getMarcador() == 'X') {
//			if(verificarVencedor() == tab.jAux.getMarcador()) {
//				return tab.jAux.getMarcador();
//			}
//		}
//
//			//o j2 (O) vencedor
//		if(tab.jAux.getMarcador() == 'O') {
//			if(verificarVencedor() == tab.jAux.getMarcador()) {
//				return tab.jAux.getMarcador();
//			}
//		}
//		//deu velha
//		if (tab.getJogadas() == 10) {	
//			return 'E';
//		}
//			//jogo continua
//			        return 'N';
//    }
	
	public void setTab(Tabuleiro t) {
		tab = t;
	}
}
