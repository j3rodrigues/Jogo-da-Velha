import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JCheckBox;
import javax.swing.JButton;

public class GUI extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private Jogador j1;
	private Jogador j2;

	private Tabuleiro tab;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GUI frame = new GUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public GUI() {
		j1 = new Jogador('X');
		j2 = new Jogador('O');
		tab = new Tabuleiro(j1, j2);
		
		setForeground(new Color(64, 0, 0));
		setFont(new Font("Cambria Math", Font.BOLD | Font.ITALIC, 20));
		setTitle("Jogo da Velha");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 494, 534);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(174, 174, 174));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton panel_2_0 = new JButton();
		panel_2_0.setFont(new Font("Tahoma", Font.PLAIN, 50));
		panel_2_0.setBackground(new Color(192, 192, 192));
		panel_2_0.setBounds(44, 393, 85, 88);
		contentPane.add(panel_2_0);
		
		JButton panel_2_1 = new JButton();
		panel_2_1.setFont(new Font("Tahoma", Font.PLAIN, 50));
		panel_2_1.setBackground(new Color(192, 192, 192));
		panel_2_1.setBounds(209, 393, 85, 88);
		contentPane.add(panel_2_1);
		
		JButton panel_2_2 = new JButton();
		panel_2_2.setFont(new Font("Tahoma", Font.PLAIN, 50));
		panel_2_2.setBackground(new Color(192, 192, 192));
		panel_2_2.setBounds(378, 393, 85, 88);
		contentPane.add(panel_2_2);
		
		JButton panel_1_0 = new JButton();
		panel_1_0.setFont(new Font("Tahoma", Font.PLAIN, 50));
		panel_1_0.setBackground(new Color(192, 192, 192));
		panel_1_0.setBounds(44, 268, 85, 88);
		contentPane.add(panel_1_0);
		
		JButton panel_1_1 = new JButton();
		panel_1_1.setFont(new Font("Tahoma", Font.PLAIN, 50));
		panel_1_1.setBackground(new Color(192, 192, 192));
		panel_1_1.setBounds(209, 268, 85, 88);
		contentPane.add(panel_1_1);
		
		JButton panel_1_2 = new JButton();
		panel_1_2.setFont(new Font("Tahoma", Font.PLAIN, 50));
		panel_1_2.setBackground(Color.LIGHT_GRAY);
		panel_1_2.setBounds(378, 268, 85, 88);
		contentPane.add(panel_1_2);
		
		JButton panel_0_0 = new JButton();
		panel_0_0.setFont(new Font("Tahoma", Font.PLAIN, 50));
		panel_0_0.setBackground(Color.LIGHT_GRAY);
		panel_0_0.setBounds(44, 145, 85, 88);
		contentPane.add(panel_0_0);
		
		JButton panel_0_1 = new JButton();
		panel_0_1.setFont(new Font("Tahoma", Font.PLAIN, 50));
		panel_0_1.setBackground(Color.LIGHT_GRAY);
		panel_0_1.setBounds(209, 145, 85, 88);
		contentPane.add(panel_0_1);
		
		JButton panel_0_2 = new JButton();
		panel_0_2.setFont(new Font("Tahoma", Font.PLAIN, 50));
		panel_0_2.setBackground(Color.LIGHT_GRAY);
		panel_0_2.setBounds(378, 145, 85, 88);
		contentPane.add(panel_0_2);
		
		JButton mGui [][] = {{panel_0_0, panel_0_1, panel_0_2},
							{panel_1_0, panel_1_1, panel_1_2},
							{panel_2_0, panel_2_1,  panel_2_2}};
		
		
		JLabel titulo = new JLabel("JOGO DA VELHA");
		titulo.setFont(new Font("Javanese Text", Font.BOLD | Font.ITALIC, 20));
		titulo.setBounds(159, 10, 190, 31);
		contentPane.add(titulo);
		
		JCheckBox JogadorX = new JCheckBox("1- Jogador 'X'");
		JogadorX.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tab.caso = 1;
			}
		});
		
		JogadorX.setFont(new Font("Tahoma", Font.BOLD, 12));
		JogadorX.setForeground(new Color(0, 0, 0));
		JogadorX.setBounds(59, 47, 118, 37);
		contentPane.add(JogadorX);
		
		JCheckBox JogadorO = new JCheckBox("2- Jogador 'O'");
		JogadorO.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tab.caso = 2;
			}
		});
		JogadorO.setForeground(Color.BLACK);
		JogadorO.setFont(new Font("Tahoma", Font.BOLD, 12));
		JogadorO.setBounds(59, 86, 118, 37);
		contentPane.add(JogadorO);
		
		JLabel resultadoJogo = new JLabel("RESULTADO");
		resultadoJogo.setFont(new Font("Javanese Text", Font.ITALIC, 20));
		resultadoJogo.setBounds(227, 104, 180, 31);
		contentPane.add(resultadoJogo);
		
		JButton iniciePartidaButton = new JButton("Inicie a Partida");
		iniciePartidaButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println(tab.caso);
				//tab.reiniciarTabuleiro();
				do{
					tab.jogar();
					for (int i = 0; i < 3; i++) {
						for (int j = 0; j < 3; j++) {
							mGui[i][j].setText(tab.getMatriz(i, j)+"");
						}
					}
					resultadoJogo.setText("");
					if(tab.verificarVencedor() == 'X' || tab.verificarVencedor() == 'O') {
						resultadoJogo.setText(tab.jAux.getMarcador() + " eh VENCEDOR!!");
						break;
					}else if (tab.verificarVencedor() == 'E') {
						resultadoJogo.setText("Deu Velha!!");
						break;
					}
				}while (tab.verificarVencedor() == 'N');
			}
		});
		iniciePartidaButton.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
		iniciePartidaButton.setBounds(265, 47, 134, 37);
		contentPane.add(iniciePartidaButton);
		
	}
}
